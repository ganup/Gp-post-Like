=== Gp post Like  ===
Contributors: ganeshpaygude,clarionwpdeveloper
Tags: like,post like,voting,post voting,post like.
Requires at least: 3.2
Tested up to: 4.4.1
Stable tag: 1.0
License: GPLv2

Allow user add post like button above or below post content.

== Description ==

Allow user add post like button above or below post content

Major features in Gp post Like include:

* Setting option checkbox  Allow user add post like button above or below post content

== Installation ==


1. Upload the plugin files to the '/wp-content/plugins/' directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress


== Frequently Asked Questions ==

=What are the system requirements?=
PHP 5.2.x or higher with JSON extensions
WordPress 3.5 or above

=Is it compatible with WordPress MultiSite?=
Yes

=Is it compatible with BuddyPress?=
Yes

Will update this in next verion.

== Screenshots ==

1. Screenshot-1 

== Changelog ==

= 1.0 =
* current version 1.0 


== Upgrade Notice ==

= 1.0 =
currently no upgrades sections

== Arbitrary section ==


== A brief Markdown Example ==

